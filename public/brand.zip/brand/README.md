# Livepeer Brand Asset Guidelines

If you are using the Livepeer logo, take note that there are two versions. One
for smaller applications and one for larger.

Our main brand color is #00EB88.
